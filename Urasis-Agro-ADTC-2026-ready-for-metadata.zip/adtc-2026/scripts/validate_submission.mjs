import fs from "node:fs";
import path from "node:path";
import process from "node:process";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const required = ["metadata.json", "download_model.sh", "REPORT.md", ".gitignore", "LICENSE", "NOTICE"];
const errors = [];

for (const file of required) {
  if (!fs.existsSync(path.join(root, file))) errors.push(`Missing required file: ${file}`);
}

const metadata = JSON.parse(fs.readFileSync(path.join(root, "metadata.json"), "utf8"));
if (metadata.domain !== "agriculture") errors.push("domain must be agriculture");
if (metadata.model?.runtime !== "llama.cpp") errors.push("runtime must be llama.cpp");
if (!metadata._runtime?.model_path?.endsWith(".gguf")) errors.push("model_path must target a GGUF file");
if (!Array.isArray(metadata.test_prompts) || metadata.test_prompts.length !== 2) {
  errors.push("metadata must contain exactly two test prompts");
}
if (!metadata.language_scope?.includes("sw") || metadata.african_alpha_claim !== true) {
  errors.push("Swahili language scope and African Alpha claim must be enabled");
}

const ignore = fs.readFileSync(path.join(root, ".gitignore"), "utf8");
if (!ignore.includes("*.gguf") || !ignore.includes("model/*")) {
  errors.push(".gitignore must exclude GGUF weights and model contents");
}

const setupScript = fs.readFileSync(path.join(root, "scripts", "setup_ubuntu.sh"), "utf8");
if (!setupScript.includes("LLAMA_CPP_TAG") || !setupScript.includes("-DLLAMA_CURL=OFF")) {
  errors.push("Ubuntu setup must pin llama.cpp and disable network-backed model loading");
}

const downloadScript = fs.readFileSync(path.join(root, "download_model.sh"), "utf8");
if (!/MODEL_SHA256="[a-f0-9]{64}"/.test(downloadScript)) {
  errors.push("download_model.sh must declare a 64-character SHA-256");
}

if (process.argv.includes("--final")) {
  const serialized = JSON.stringify(metadata);
  if (serialized.includes("PENDING_")) errors.push("pending metadata remains");
}

if (errors.length) {
  for (const error of errors) console.error(`ERROR: ${error}`);
  process.exit(1);
}

const corpusLines = fs.readFileSync(path.join(root, "corpus", "agriculture_sw_fr.jsonl"), "utf8")
  .split(/\r?\n/).filter(Boolean).map(JSON.parse);
console.log(JSON.stringify({
  status: "valid-draft",
  domain: metadata.domain,
  runtime: metadata.model.runtime,
  languages: metadata.language_scope,
  test_prompts: metadata.test_prompts.length,
  corpus_records: corpusLines.length,
}, null, 2));
